<?php

namespace HipsterJazzbo\Landlord\Exceptions;

interface TenantExceptionInterface
{
    //
}
