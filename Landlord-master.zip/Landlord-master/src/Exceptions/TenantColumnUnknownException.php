<?php

namespace HipsterJazzbo\Landlord\Exceptions;

use Exception;

class TenantColumnUnknownException extends Exception implements TenantExceptionInterface
{
    //
}
