<?php

namespace HipsterJazzbo\Landlord\Exceptions;

use Exception;

class TenantNullIdException extends Exception implements TenantExceptionInterface
{
    //
}
