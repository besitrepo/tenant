<?php

namespace HipsterJazzbo\Landlord\Exceptions;

use Exception;

class TenantNotSetException extends Exception implements TenantExceptionInterface
{
    //
}
